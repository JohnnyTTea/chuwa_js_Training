import { useState } from "react";

//User login Info
// const database = [
//   { email: "Tony@gmail.com", password: "To123" },
//   { email: "Wong@hotmail.com", password: "Wong133" },
// ];
const Input = () => {
  const [errorMessage, setErrorMessage] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [message, setMessage] = useState("");

  const onChange = (event) => {
    setMessage(event.target.value);

    if (message.includes("@")) {
      setIsSubmitted(true);
    } else {
      setIsSubmitted(false);
      setErrorMessage("Invalid Email Address");
    }
  };

  const handleSubmit = () => {
    if (isSubmitted) {
      openNewTab("https://css-tricks.com/snippets/css/a-guide-to-flexbox/");
    } else {
      redenerError();
    }
  };

  const redenerError = () => {
    !isSubmitted && <div>{errorMessage}</div>;
  };
  const openNewTab = (url) => {
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="form_container">
      <div className="email_container">
        <h2>Sign in to your account</h2>
        <div className="email_text">Email</div>
        <input
          type="text"
          className="email"
          onChange={onChange}
          value={message}
        ></input>
        <div>{redenerError()}</div>
      </div>
      <div className="password_container">
        <div className="pass_text">Password</div>
        <input type="password" className="password"></input>
      </div>
      <div>
        <button className="sign_in_button" onClick={handleSubmit}>
          <div className="button_content">Sign in</div>
        </button>

        <div className="queston_container">
          <div className="account_sign_up">
            <span className="account">Don't have an account?</span>
            <span className="sign_up" id="underline">
              Sign up
            </span>
          </div>
          {/* <div className="forgot_pass" id="underline">
            Forgot password?
          </div> */}
        </div>
      </div>
    </div>
  );
};
export default Input;
