import React, { useState } from "react";

import PopUp from "./components/PopUp";
//import Input from "./components/Input";
import "./App.css";
// import "./components/window.css";

export default class App extends React.Component {
  state = {
    seen: false,
  };
  togglePop = () => {
    this.setState({
      seen: !this.state.seen,
    });
  };
  render() {
    return (
      <div>
        <div className="btn" onClick={this.togglePop}>
          <button>LOGIN IN</button>
        </div>
        {this.state.seen ? <PopUp toggle={this.togglePop} /> : null}
      </div>
    );
  }
}

// export default App;
