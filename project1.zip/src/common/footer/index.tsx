import React from "react";
import "./index.css";

const Footer = () => {
    return <div className="footer"></div>
}

export default Footer;