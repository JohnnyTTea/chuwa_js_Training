import React from "react";
import "./index.css";

const Header = () => {
    return <div className="header"></div>
}

export default Header;