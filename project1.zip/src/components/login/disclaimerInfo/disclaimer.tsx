//open the disclaimer
import React from "react";
import Input from "./input";

// import Input from "./input";

const Disclaimer = (props: any) => {
  return (
    <div className="modal">
      <div className="modal_content">
        {/* <span className="close" onClick={handleClick}>
          &times;
        </span> */}
        <span className="close" onClick={props.handleClose}>
          &times;
        </span>
        {/* {props.content} */}
        <Input />
      </div>
    </div>
  );
};

export default Disclaimer;
