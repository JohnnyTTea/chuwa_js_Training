import React, { useState } from "react";
import { Button } from "antd";

import Modal from "../../common/modal";
import ModalContent from "./modalContent";

import { LOGIN_FORM } from "../../content/form";
import "./index.css";

const Login = ({ handleLogin = () => {} }) => {
  const [visible, setVisible] = useState(false);

  //disclaimer form
  // const disClaimer=()=>{

  // }

  return (
    <>
      <Button type="primary" onClick={() => setVisible(true)}>
        {LOGIN_FORM.LOGIN}
      </Button>
      <Modal
        titleText={LOGIN_FORM.LOGIN}
        visible={visible}
        setVisible={setVisible}
      >
        <ModalContent handleOnLogin={handleLogin} />
      </Modal>
    </>
  );
};

export default Login;
